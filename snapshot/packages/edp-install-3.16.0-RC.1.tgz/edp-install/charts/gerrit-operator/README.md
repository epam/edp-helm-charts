# gerrit-operator

![Version: 2.25.0](https://img.shields.io/badge/Version-2.25.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 2.25.0](https://img.shields.io/badge/AppVersion-2.25.0-informational?style=flat-square)

A Helm chart for KubeRocketCI Gerrit Operator

**Homepage:** <https://docs.kuberocketci.io/>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| epmd-edp | <SupportEPMD-EDP@epam.com> | <https://solutionshub.epam.com/solution/kuberocketci> |
| sergk |  | <https://github.com/SergK> |

## Source Code

* <https://github.com/epam/edp-gerrit-operator>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| annotations | object | `{}` |  |
| gerrit.affinity | object | `{}` |  |
| gerrit.annotations | object | `{}` |  |
| gerrit.basePath | string | `""` | Base path for Nexus URL |
| gerrit.caCerts.enabled | bool | `false` | Flag for enabling additional CA certificates |
| gerrit.caCerts.image | string | `"adoptopenjdk/openjdk11:alpine"` | Change init CA certificates container image |
| gerrit.caCerts.secret | string | `"secret-name"` | Name of the secret containing additional CA certificates |
| gerrit.deploy | bool | `true` | Flag to enable/disable Gerrit deploy |
| gerrit.extraEnv | list | `[]` | Additional environment variables |
| gerrit.image | string | `"epamedp/edp-gerrit"` | Define gerrit docker image name |
| gerrit.imagePullPolicy | string | `"IfNotPresent"` | If defined, a imagePullPolicy applied for gerrit deployment |
| gerrit.imagePullSecrets | string | `nil` | Secrets to pull from private Docker registry; |
| gerrit.ingress.annotations | object | `{}` |  |
| gerrit.ingress.pathType | string | `"Prefix"` | pathType is only for k8s >= 1.1= |
| gerrit.ingress.tls | list | `[]` | See https://kubernetes.io/blog/2020/04/02/improvements-to-the-ingress-api-in-kubernetes-1.18/#specifying-the-class-of-an-ingress ingressClassName: nginx |
| gerrit.javaOptions | string | `""` | Values to add to JAVA_OPTIONS |
| gerrit.name | string | `"gerrit"` | Gerrit name |
| gerrit.nodeSelector | object | `{}` |  |
| gerrit.port | string | `"8080"` | HTTP port |
| gerrit.resources.limits.memory | string | `"2Gi"` |  |
| gerrit.resources.requests.cpu | string | `"100m"` |  |
| gerrit.resources.requests.memory | string | `"512Mi"` |  |
| gerrit.sshHostKeys.enabled | bool | `false` | Flag for enabling SSH host key injection from a pre-created Secret |
| gerrit.sshHostKeys.secret | string | `"gerrit-ssh-host-keys"` | Name of the secret containing the SSH host key pairs |
| gerrit.sso.enabled | bool | `true` |  |
| gerrit.sso.keycloakUrl | string | `"https://keycloak.example.com/auth"` | Keycloak URL. |
| gerrit.sso.kind | string | `"KeycloakRealm"` |  |
| gerrit.sso.name | string | `"main"` |  |
| gerrit.sso.quickLink.enabled | bool | `true` |  |
| gerrit.storage.size | string | `"1Gi"` | Size for Gerrit data volume |
| gerrit.tolerations | list | `[]` |  |
| gerrit.version | string | `"3.14.2"` | Define gerrit docker image tag |
| global.admins | list | `["stub_user_one@example.com"]` | Administrators of your tenant |
| global.developers | list | `["stub_user_one@example.com","stub_user_two@example.com"]` | Developers of your tenant |
| global.dnsWildCard | string | `nil` | a cluster DNS wildcard name |
| global.gerritSSHPort | string | `"30022"` | Gerrit SSH node port |
| global.openshift.deploymentType | string | `"deployments"` | Which type of kind will be deployed to Openshift (values: deployments/deploymentConfigs) |
| global.platform | string | `"openshift"` | platform type that can be "kubernetes" or "openshift" |
| groupMemberSyncInterval | string | `"30m"` | If not defined the exponential formula with the max value of 1hr will be used |
| image.repository | string | `"epamedp/gerrit-operator"` | KubeRocketCI gerrit-operator Docker image name. The released image can be found on [Dockerhub](https://hub.docker.com/r/epamedp/gerrit-operator) |
| image.tag | string | `nil` | KubeRocketCI gerrit-operator Docker image tag. The released image can be found on [Dockerhub](https://hub.docker.com/r/epamedp/gerrit-operator/tags) |
| imagePullPolicy | string | `"IfNotPresent"` |  |
| imagePullSecrets | list | `[]` | Optional array of imagePullSecrets containing private registry credentials # Ref: https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry |
| name | string | `"gerrit-operator"` | component name |
| nodeSelector | object | `{}` |  |
| podSecurityContext | object | `{"runAsNonRoot":true}` | Pod Security Context Ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ |
| projectSyncInterval | string | `"1h"` | Format: golang time.Duration-formatted string |
| resources.limits.memory | string | `"192Mi"` |  |
| resources.requests.cpu | string | `"50m"` |  |
| resources.requests.memory | string | `"64Mi"` |  |
| securityContext | object | `{"allowPrivilegeEscalation":false}` | Container Security Context Ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ |
| tolerations | list | `[]` |  |

