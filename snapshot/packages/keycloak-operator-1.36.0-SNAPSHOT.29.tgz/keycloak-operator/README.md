# keycloak-operator

![Version: 1.36.0-SNAPSHOT](https://img.shields.io/badge/Version-1.36.0--SNAPSHOT-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.36.0-SNAPSHOT](https://img.shields.io/badge/AppVersion-1.36.0--SNAPSHOT-informational?style=flat-square)

A Helm chart for KubeRocketCI Keycloak Operator

**Homepage:** <https://docs.kuberocketci.io/>

## Overview

Keycloak Operator is a KubeRocketCI operator responsible for configuring existing Keycloak instances. The operator runs both on OpenShift and Kubernetes.

_**NOTE:** Operator is platform-independent, which is why there is a unified instruction for deployment._

## Prerequisites

1. Linux machine or Windows Subsystem for Linux instance with [Helm 3](https://helm.sh/docs/intro/install/) installed;
2. Cluster admin access to the cluster;
3. [cert-manager](https://cert-manager.io/docs/installation/) installed in the cluster (required for webhook functionality, can be disabled via `enableWebhooks: false`);

## Installation Using Helm Chart

To install the Keycloak Operator, follow the steps below:

1. To add the Helm EPAMEDP Charts for a local client, run "helm repo add":

     ```bash
     helm repo add epamedp https://epam.github.io/edp-helm-charts/stable
     ```

2. Choose the available Helm chart version:

     ```bash
     helm search repo epamedp/keycloak-operator -l
     NAME                           CHART VERSION   APP VERSION     DESCRIPTION
     epamedp/keycloak-operator      1.31.0          1.31.0          A Helm chart for KRCI Keycloak Operator
     ```

    _**NOTE:** It is highly recommended to use the latest stable version._

3. Full chart parameters available below.

4. Install the operator in the <edp-project> namespace with the helm command; find below the installation command example:

    ```bash
    helm install keycloak-operator epamedp/keycloak-operator --version <chart_version> --namespace <edp-project> --set name=keycloak-operator
    ```

5. Check the <edp-project> namespace containing Deployment with your operator in running status.

## Quick Start

1. Create a User in the Keycloak `Master` realm, and assign a `create-realm` role.

2. Insert newly created user credentials into Kubernetes secret:

    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name:  keycloak-access
    type: Opaque
    data:
      username: dXNlcg==   # base64-encoded value of "user"
      password: cGFzcw==   # base64-encoded value of "pass"
    ```

3. Create Custom Resource `kind: Keycloak` with Keycloak instance URL and secret created on the previous step:

    ```yaml
    apiVersion: v1.edp.epam.com/v1
    kind: Keycloak
    metadata:
      name: keycloak-sample
    spec:
      secret: keycloak-access             # Secret name
      url: https://keycloak.example.com   # Keycloak URL
    ```

    Wait for the `.status` field with  `status.connected: true`

4. Create Keycloak realm and group using Custom Resources:

   ```yaml
   apiVersion: v1.edp.epam.com/v1
   kind: KeycloakRealm
   metadata:
     name: keycloakrealm-sample
   spec:
     realmName: realm-sample
     keycloakRef:
       name: keycloak-sample   # the name of `kind: Keycloak`
       kind: Keycloak
    ```

    ```yaml
    apiVersion: v1.edp.epam.com/v1
    kind: KeycloakRealmGroup
    metadata:
      name: argocd-admins
    spec:
      name: ArgoCDAdmins
      realmRef:
        name: keycloakrealm-sample   # the name of `kind: KeycloakRealm`
        kind: KeycloakRealm
    ```

    Inspect [available custom resource](./docs/arch.md) and [CR templates folder](./deploy-templates/_crd_examples/) for more examples

## Local Development

To develop the operator, first set up a local environment, and refer to the [Local Development](https://docs.kuberocketci.io/docs/developer-guide/local-development) page.

Development versions are also available from the [snapshot helm chart repository](https://epam.github.io/edp-helm-charts/snapshot/) page.

### Related Articles

* [Install KubeRocketCI](https://docs.kuberocketci.io/docs/operator-guide/install-kuberocketci)

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| epmd-edp | <SupportEPMD-EDP@epam.com> | <https://solutionshub.epam.com/solution/kuberocketci> |
| sergk |  | <https://github.com/SergK> |

## Source Code

* <https://github.com/epam/edp-keycloak-operator>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity for pod assignment |
| allowedDestinationHosts | list | `[]` | Hostnames the operator and Keycloak may reach with credentials resolved from Secrets. Covers Keycloak spec.url, realm spec.smtp.connection.host, and the known destination keys (tokenUrl, connectionUrl, ...) inside identity provider and realm component config. Values in other config keys are not checked. Exact, case-insensitive match; no wildcards. Write the hostname only, without scheme, port or path, and prefer fully qualified names. An empty list means no policy: every destination is allowed and nothing is logged or counted. Add at least one host (for example the Keycloak host) to turn on reporting. |
| annotations | object | `{}` | Annotations to be added to the Deployment |
| clusterDomain | string | `"cluster.local"` | Cluster domain for constructing service DNS names |
| clusterReconciliationEnabled | bool | `false` | If clusterReconciliationEnabled is true, the operator reconciles all Keycloak instances in the cluster;  otherwise, it only reconciles instances in the same namespace by default, and cluster-scoped resources are ignored. |
| containerSecurityContext | object | `{"allowPrivilegeEscalation":false}` | Container Security Context Ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ |
| enableOwnerRef | bool | `true` | If set to true, the operator will set the owner reference for all resources that have Keycloak or KeycloakRealm as reference. This is legacy behavior and not recommended for use. In the future, this will be set to false by default. |
| enableWebhooks | bool | `true` | If set to true, enables webhook resources (ValidatingWebhookConfiguration, Service, and Certificate). Webhooks require cert-manager to be installed in the cluster. |
| enforceDestinationAllowlist | bool | `false` | If true, a destination absent from allowedDestinationHosts fails the reconcile. If false, destinations absent from a non-empty list are logged and counted, so the list can be built from a running cluster before enforcement is turned on. Enabling this with an empty allowedDestinationHosts stops the operator at startup. |
| extraVolumeMounts | list | `[]` | Additional volumeMounts to be added to the container |
| extraVolumes | list | `[]` | Additional volumes to be added to the pod |
| image.registry | string | `""` | KubeRocketCI keycloak-operator Docker image registry. |
| image.repository | string | `"epamedp/keycloak-operator"` | KubeRocketCI keycloak-operator Docker image name. The released image can be found on [Dockerhub](https://hub.docker.com/r/epamedp/keycloak-operator) |
| image.tag | string | `nil` | KubeRocketCI keycloak-operator Docker image tag. The released image can be found on [Dockerhub](https://hub.docker.com/r/epamedp/keycloak-operator/tags) |
| imagePullPolicy | string | `"IfNotPresent"` | If defined, a imagePullPolicy applied to the deployment |
| imagePullSecrets | list | `[]` | If defined, imagePullSecrets are applied to deployment |
| name | string | `"keycloak-operator"` | Application name string |
| nodeSelector | object | `{}` | Node labels for pod assignment |
| podLabels | object | `{}` | Labels to be added to the pod |
| replicaCount | int | `1` | Number of operator replicas. |
| resources | object | `{"limits":{"memory":"192Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}` | Resource limits and requests for the pod |
| securityContext | object | `{"runAsNonRoot":true}` | Deployment Security Context Ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ |
| serviceAccount | object | `{"annotations":{},"create":true,"labels":{},"name":"edp-keycloak-operator"}` | ServiceAccount configuration |
| serviceAccount.annotations | object | `{}` | Annotations to add to the ServiceAccount (e.g. for AWS IAM role association) |
| serviceAccount.create | bool | `true` | If true, a ServiceAccount will be created |
| serviceAccount.labels | object | `{}` | Additional labels to add to the ServiceAccount |
| serviceAccount.name | string | `"edp-keycloak-operator"` | The name of the ServiceAccount to use. Defaults to "edp-keycloak-operator" |
| tolerations | list | `[]` | Node tolerations for server scheduling to nodes with taints |
