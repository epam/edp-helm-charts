# krci-portal

![Version: 0.8.0-SNAPSHOT](https://img.shields.io/badge/Version-0.8.0--SNAPSHOT-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.8.0-SNAPSHOT](https://img.shields.io/badge/AppVersion-0.8.0--SNAPSHOT-informational?style=flat-square)

A Helm chart for KubeRocketCI Portal

**Homepage:** <https://docs.kuberocketci.io/>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| epmd-edp | <SupportEPMD-EDP@epam.com> | <https://solutionshub.epam.com/solution/kuberocketci> |
| sergk |  | <https://github.com/SergK> |

## Source Code

* <https://github.com/KubeRocketCI/krci-portal>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity for pod assignment https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#affinity-and-anti-affinity |
| autoscaling | object | `{"enabled":false,"maxReplicas":100,"minReplicas":1,"targetCPUUtilizationPercentage":80}` | Horizontal Pod Autoscaler configuration |
| autoscaling.enabled | bool | `false` | Enable autoscaling |
| autoscaling.maxReplicas | int | `100` | Maximum number of replicas |
| autoscaling.minReplicas | int | `1` | Minimum number of replicas |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | Target CPU utilization percentage |
| configEnv.API_PREFIX | string | `"/api"` |  |
| configEnv.DEFAULT_CLUSTER_NAME | string | `"core"` |  |
| configEnv.DEFAULT_CLUSTER_NAMESPACE | string | `"krci"` |  |
| configEnv.DEPENDENCY_TRACK_URL | string | `"https://deptrack.example.com"` |  |
| configEnv.DEPLOY_CLIENT_DIST_DIR | string | `"/app/static"` |  |
| configEnv.GITFUSION_URL | string | `"http://gitfusion.krci:8080"` |  |
| configEnv.KRCI_AUDIT_URL | string | `"http://krci-audit-api.krci-audit:8080"` |  |
| configEnv.OIDC_CLIENT_ID | string | `"portal"` |  |
| configEnv.OIDC_CODE_CHALLENGE_METHOD | string | `"S256"` |  |
| configEnv.OIDC_ISSUER_URL | string | `"https://keycloak.example.com/realms/shared"` |  |
| configEnv.OIDC_SCOPE | string | `"openid profile email"` |  |
| configEnv.PORTAL_URL | string | `"https://portal.example.com"` |  |
| configEnv.PROMETHEUS_URL | string | `"http://prometheus.monitoring.svc:9090"` |  |
| configEnv.SERVER_PORT | int | `3000` |  |
| configEnv.SONAR_HOST_URL | string | `"https://sonar.example.com/"` |  |
| configEnv.TEKTON_RESULTS_URL | string | `"https://tekton-results.example.com"` |  |
| eso.apiVersion | string | `"external-secrets.io/v1"` | Defines API version for the ExternalSecret resource. |
| eso.aws | object | `{"region":"eu-central-1","roleArn":"arn:aws:iam::012345678910:role/AWSIRSA_Shared_ExternalSecretOperatorAccess"}` | AWS configuration (if provider is `aws`). |
| eso.aws.region | string | `"eu-central-1"` | AWS region. |
| eso.aws.roleArn | string | `"arn:aws:iam::012345678910:role/AWSIRSA_Shared_ExternalSecretOperatorAccess"` | AWS role ARN for the ExternalSecretOperator to assume. |
| eso.enabled | bool | `false` | Install components of the ESO. |
| eso.generic.secretStore.providerConfig | object | `{}` | Defines SecretStore provider configuration. |
| eso.provider | string | `"aws"` | Defines provider type. One of `aws`, `generic`, or `vault`. |
| eso.secretPath | string | `"/infra/core/addons/krci-portal"` | Defines the path to the secret in the provider. If provider is `vault`, this is the path must be prefixed with `secret/`. |
| eso.vault | object | `{"mountPath":"core","role":"krci-portal","server":"http://vault.vault:8200"}` | Vault configuration (if provider is `vault`). |
| eso.vault.mountPath | string | `"core"` | Mount path for the Kubernetes authentication method. |
| eso.vault.role | string | `"krci-portal"` | Vault role for the Kubernetes authentication method. |
| eso.vault.server | string | `"http://vault.vault:8200"` | Vault server URL. |
| fullnameOverride | string | `"krci-portal"` | Override the full name of the chart |
| httproute | object | `{"annotations":{},"dnsWildcard":"","enabled":false,"hostnames":["edpDefault"],"matches":[{"path":{"type":"PathPrefix","value":"/"}}],"parentRefs":[{"name":"main-gateway","namespace":"envoy-gateway-system"}]}` | HTTPRoute (Gateway API / Envoy Gateway) configuration. Alternative to `ingress` for clusters migrating from nginx-ingress to Envoy Gateway. When enabled, an HTTPRoute is created and attached to the referenced Gateway alongside the (optional) nginx Ingress, which stays as the instant rollback path. Disabled by default (enable per environment via values). Enable only on clusters that serve the Gateway API — if the CRDs are absent the resource fails at apply time with a clear "no matches for kind HTTPRoute" error. |
| httproute.annotations | object | `{}` | Annotations to add to the HTTPRoute |
| httproute.dnsWildcard | string | `""` | Cluster-wide DNS wildcard domain (e.g. `apps.cluster.example.com`). Used to build the default hostname as `<fullname>-<namespace>.<dnsWildcard>` when `hostnames` contains `edpDefault`. Required when using the `edpDefault` hostname sentinel. |
| httproute.enabled | bool | `false` | Enable HTTPRoute (Gateway API) resource. Enable only on clusters that serve the Gateway API (`gateway.networking.k8s.io`); the nginx Ingress above stays as the rollback path. |
| httproute.hostnames | list | `["edpDefault"]` | Hostnames for the route. 'edpDefault' renders `<fullname>-<namespace>.<dnsWildcard>` — the same host the Ingress template renders, so the route takes over exactly the Ingress host. |
| httproute.matches | list | `[{"path":{"type":"PathPrefix","value":"/"}}]` | Path matches for the route rule |
| httproute.parentRefs | list | `[{"name":"main-gateway","namespace":"envoy-gateway-system"}]` | Parent Gateways the route attaches to (name + namespace of the Envoy Gateway) |
| image | object | `{"pullPolicy":"IfNotPresent","repository":"epamedp/krci-portal","tag":""}` | Image configuration |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"epamedp/krci-portal"` | Image repository |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | Image pull secrets for private registries |
| ingress | object | `{"annotations":{},"className":"","dnsWildcard":"","enabled":false,"hosts":[{"host":"edpDefault","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}],"tls":[]}` | Ingress configuration |
| ingress.annotations | object | `{}` | Ingress annotations |
| ingress.className | string | `""` | Ingress class name |
| ingress.dnsWildcard | string | `""` | DNS wildcard for the cluster |
| ingress.enabled | bool | `false` | Enable ingress |
| ingress.hosts | list | `[{"host":"edpDefault","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}]` | Ingress hosts configuration |
| ingress.tls | list | `[]` | TLS configuration |
| livenessProbe | object | `{"tcpSocket":{"port":"http"}}` | Liveness probe configuration |
| nameOverride | string | `""` | Override the name of the chart |
| nodeSelector | object | `{}` | Node selector for pod assignment https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#nodeselector |
| persistence | object | `{"accessModes":["ReadWriteOnce"],"annotations":{},"enabled":false,"existingClaim":"","size":"1Gi","storageClass":""}` | Persistence for the SQLite session/events database. A ReadWriteOnce PVC mounted at the server's DB directory (`/app/db`) keeps sessions across pod restarts (RWO forces the Recreate strategy). Removed on `helm uninstall` — no retention policy. |
| persistence.accessModes | list | `["ReadWriteOnce"]` | Access modes for the PVC (RWO is required for the SQLite file lock) |
| persistence.annotations | object | `{}` | Extra annotations for the PVC |
| persistence.enabled | bool | `false` | Enable persistent storage for the SQLite database. Disabled by default. |
| persistence.existingClaim | string | `""` | Bind an existing PVC instead of creating one. When set, no PVC is created. |
| persistence.size | string | `"1Gi"` | Size of the PVC |
| persistence.storageClass | string | `""` | StorageClass for the PVC. Empty uses the cluster default; "-" disables dynamic provisioning. |
| podAnnotations | object | `{}` | Pod annotations |
| podLabels | object | `{}` | Pod labels |
| podSecurityContext | object | `{"fsGroup":1000,"runAsGroup":1000,"runAsNonRoot":true,"runAsUser":1000,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context. `fsGroup` chowns the persistence volume to this GID on mount so the non-root container can write the SQLite database. |
| readinessProbe | object | `{"initialDelaySeconds":20,"tcpSocket":{"port":"http"}}` | Readiness probe configuration |
| replicaCount | int | `1` | Number of replicas for the deployment |
| resources | object | `{}` | Resource limits and requests |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | Container security context |
| service | object | `{"port":3000,"type":"ClusterIP"}` | Service configuration |
| service.type | string | `"ClusterIP"` | Service type |
| serviceAccount | object | `{"annotations":{},"automount":true,"create":true,"name":""}` | Service account configuration |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.automount | bool | `true` | Automatically mount a ServiceAccount's API credentials? |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| tolerations | list | `[]` | Tolerations for pod assignment https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/ |
| volumeMounts | list | `[]` | Additional volumeMounts on the output Deployment definition. |
| volumes | list | `[]` | Additional volumes on the output Deployment definition. |
