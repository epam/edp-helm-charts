# krci-substrate

![Version: 0.5.0-SNAPSHOT](https://img.shields.io/badge/Version-0.5.0--SNAPSHOT-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.5.0-SNAPSHOT](https://img.shields.io/badge/AppVersion-0.5.0--SNAPSHOT-informational?style=flat-square)

A Helm chart for upstream Agent Substrate, matching the upstream ate-setup install

**Homepage:** <https://docs.kuberocketci.io/>

## Introduction

The chart installs objects of [Agent Substrate](https://github.com/agent-substrate/substrate) release `v1.0.1`. The chart `version` and `appVersion` are the chart release.
Each chart object copied from upstream equals its reference install object: what upstream `ate-setup deploy ate-system` applies for that release, with the envoy dataplane on a non-kind cluster. Exceptions: [Deviations from the reference install](#deviations-from-the-reference-install).

Objects copied from the upstream manifests of the release tag:

| Chart path | Upstream path |
|---|---|
| `crds/ate.dev_*.yaml` | `manifests/ate-install/generated/ate.dev_*.yaml`, byte for byte |
| `templates/namespaces.yaml` | `manifests/ate-install/ate-system-namespace.yaml`, the Namespace of `manifests/ate-install/pod-certificate-controller.yaml` |
| `templates/podcertificate-controller/serviceaccount.yaml` | the ServiceAccount of `manifests/ate-install/pod-certificate-controller.yaml` |
| `templates/podcertificate-controller/rbac.yaml` | the ClusterRole, ClusterRoleBinding, Role and RoleBinding of `manifests/ate-install/pod-certificate-controller.yaml` |
| `templates/podcertificate-controller/deployment.yaml` | the Deployment of `manifests/ate-install/pod-certificate-controller.yaml`; image `podcertificateController.image` (`<repository>:<tag>@<digest>`) and `--preview=`, as the reference install has them |
| `templates/postgres/` | ConfigMap `postgres-config`, Service and StatefulSet of `manifests/ate-install/postgres/postgres.yaml` |
| `templates/ate-api-server/` | ClusterRole, ServiceAccount, ClusterRoleBinding, Deployment, PodDisruptionBudget and Service `api` of `manifests/ate-install/ate-api-server.yaml` |
| `templates/ate-idp-server/` | ServiceAccount, Deployment, PodDisruptionBudget and Service `idp` of `manifests/ate-install/ate-idp-server.yaml` |
| `templates/ate-controller/` | ServiceAccounts `ate-client`, `ate-controller`, the bindings, Service and Deployment of `manifests/ate-install/ate-controller.yaml`; ClusterRole and Role of `manifests/ate-install/generated/role.yaml` |
| `templates/networkpolicies.yaml` | `manifests/ate-install/ate-system-networkpolicies.yaml` |
| `templates/ate-otel-config.yaml` | `manifests/ate-install/ate-otel-config.yaml` |
| `templates/sandboxconfig/gvisor.yaml` | `manifests/ate-install/sandboxconfig-gvisor.yaml` |
| `templates/sandboxconfig/validation.yaml` | `manifests/ate-install/sandboxconfig-validation.yaml` |
| `templates/atelet/` | ServiceAccount, ClusterRole, ClusterRoleBinding, Role, RoleBinding, ResourceQuota and DaemonSet of `manifests/ate-install/atelet.yaml` |
| `templates/atenet-router/` | ServiceAccount, Role, RoleBinding, ConfigMap, Deployment and Service of `manifests/ate-install/atenet-router.yaml` |
| `templates/atenet-egress/` | ServiceAccount, ConfigMap, Deployment and Service of `manifests/ate-install/atenet-egress.yaml` |
| `templates/k8s-credential-provider/` | `manifests/egress-credential-injection/k8s-credential-provider.yaml`, `manifests/egress-credential-injection/namespace-policy.yaml` |
| `files/postgres/setup.sql` | `pkg/postgressetup/setup.sql`, byte for byte |
| `files/atenet-egress/envoy.yaml` | key `envoy.yaml` of ConfigMap `atenet-egress` in `manifests/ate-install/atenet-egress.yaml`, byte for byte |

Reference install changes in every substrate workload: image `<service>.image` (`<repository>:<tag>@<digest>`), `--preview=` appended. ate-api-server: `--authz-bootstrap-owners` appended, pod template annotation `ate.dev/env-hash`. ate-idp-server: `--issuer=https://idp.ate-system.svc` appended.

Reference install settings of the dataplane: envoy (`--atenet-dataplane=envoy`), image `envoy-dataplane` in place of `${ENVOY_DATAPLANE_IMAGE}`. Credential provider `{"name":"k8s.io"}`: k8s-credential-provider deployed; on the atenet-egress `ext-proc` container, the `--credential-provider-*` flags in place of the `#ATE_EGRESS_INJECT_FLAGS` marker, server name `k8s-credential-provider.ate-system.svc`. atenet-router: `--ingress-allowed-spiffe-ids` appended when `router.ingressAllowedSpiffeIds` is not empty. Sandbox classes: gvisor only (`--sandbox-classes=gvisor`).

Upstream objects not in the chart:

- `manifests/ate-install/atenet-router-monitoring.yaml`: PodMonitoring `atenet-router-envoy`, GKE Managed Prometheus only.
- `manifests/egress-credential-injection/sample-secret.yaml`: example; `ate-setup` does not apply it.
- `manifests/ate-install/sandboxconfig-microvm.yaml.tmpl`: microvm sandbox class; needs `/dev/kvm` and staged guest assets.

### Install order

Argo CD sync waves, annotation `argocd.argoproj.io/sync-wave` on every chart object (`templates/_helpers.tpl`, `krci-substrate.syncWave`). Argo CD applies a wave after the objects of the earlier waves are healthy.

| Wave | Objects |
|---|---|
| `0` | CRDs (`crds/`, no annotation), Namespaces, ConfigMap `ate-otel-config`, NetworkPolicies, ValidatingAdmissionPolicy `sandboxconfig-assets` |
| `1` | PKI (`templates/pki/`), podcertificate-controller, SandboxConfig `gvisor-default` |
| `2` | PostgreSQL, atelet |
| `3` | ate-api-server, ate-idp-server, ate-controller, k8s-credential-provider, atenet-router, atenet-egress |

atelet rolls out before ate-api-server on every sync. Helm without Argo CD ignores the waves.

Chart objects without an upstream manifest:

- `templates/pki/`: the cert-manager and ESO objects of the pool Secrets. The pool list: `templates/pki/_pools.tpl`.
- `templates/ate-api-server/config.yaml`: the objects `ate-setup` writes for ate-api-server, bundled PostgreSQL: ConfigMaps `ate-api-server-envvars`, `ate-api-config`, `ate-api-authentication`, Secret `ate-api-server-secret-envvars`.
- `templates/postgres/configmap.yaml`, ConfigMap `postgres-setup`: the setup SQL run of `ate-setup`.

### Deviations from the reference install

| Object | Reference install | Chart | Reason |
|---|---|---|---|
| ate-api-server, sidecar `objectstore-plugin` | GCS (`ATE_STORAGE_BACKEND=gcs`, ambient Google credentials) | S3: `ATE_STORAGE_BACKEND=s3`, `AWS_REGION`, optional `AWS_ENDPOINT_URL`, `AWS_S3_USE_PATH_STYLE`; `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` only from `snapshots.s3.credentialsSecret` | Target clusters are EKS and kind. Production: no Secret; AWS SDK default chain with EKS Pod Identity or IRSA. The Secret is for the kind test bed or an S3-compatible store with no workload identity. |
| ServiceAccount `ate-api-server` | no annotations | `apiServer.serviceAccount.annotations` | IRSA needs `eks.amazonaws.com/role-arn` on the ServiceAccount. Default: no annotations. |
| ConfigMap `ate-api-server-envvars` | `ATE_API_SNAPSHOT_LOCATION` from `--snapshot-location` | `s3://<snapshots.s3.bucket>/<snapshots.s3.prefix>/`; empty prefix: `s3://<snapshots.s3.bucket>/` | S3 bucket. The S3 backend reads the bucket from the URI host. The prefix scopes the IAM policies to one cluster. |
| ConfigMap `ate-api-authentication` | issuer from GKE coordinates or cluster OIDC discovery | `apiServer.serviceAccountIssuer` | A chart cannot query the cluster. EKS: the cluster OIDC issuer URL. |
| ConfigMap `ate-otel-config` | `OTEL_EXPORTER_OTLP_ENDPOINT` of the GKE managed collector | no endpoint; `OTEL_TRACES_EXPORTER`, `OTEL_METRICS_EXPORTER`, `ATE_WORKER_OTEL_TRACES_EXPORTER`, `ATE_WORKER_OTEL_METRICS_EXPORTER`: `none` | No collector on the target clusters yet. Logs stay on stdout. |
| StatefulSet `postgres` | `ate-setup` runs the setup SQL with `kubectl exec` after each rollout | the image entrypoint runs it from `/docker-entrypoint-initdb.d`, on an empty data directory only | No exec under GitOps. An existing volume keeps its roles and schema. |
| StatefulSet `postgres`, `postStart` hook | waits for the Unix socket, then creates `atepg` when absent | waits for TCP `127.0.0.1:5432` first | The init server of the image is socket-only. A hook during init races the entrypoint `CREATE DATABASE`; a failed hook kills the container before the setup SQL runs, and the restart skips it. |
| StatefulSet `postgres` | base size: resources and 500Gi claim; StorageClass from `--postgres-storage-class` | `postgres.resources`, `postgres.storage` | Default is the base size. Kind: the upstream kind overlay values. |
| Every chart object | no Argo CD annotations | `argocd.argoproj.io/sync-wave` | Install order under Argo CD: [Install order](#install-order). |
| DaemonSet `atelet`, sidecar `objectstore-plugin` | GCS (`ATE_STORAGE_BACKEND=gcs`, ambient Google credentials) | S3, same environment as the ate-api-server sidecar | Same as ate-api-server. |
| ServiceAccount `atelet` | no annotations | `atelet.serviceAccount.annotations` | IRSA, same as ate-api-server. |
| DaemonSet `atelet`, image credential provider | GKE host paths `/home/kubernetes/bin`, `/etc/srv/kubernetes/cri_auth_config.yaml` | `atelet.imageCredentialProvider`: host paths; `enabled: false` drops the two flags and mounts, as the upstream kind overlay does | Host paths differ per node distribution (EKS: `/etc/eks/image-credential-provider`). Default: the GKE paths. |
| Deployments `atenet-router`, `atenet-egress`, pod template | atenet-router: annotations `prometheus.io/scrape`, `prometheus.io/port`; atenet-egress: no annotations. `ate-setup` restarts `atenet-egress` after each deploy with a credential provider | annotation `checksum/config` added, the sha256 of the rendered ConfigMap | Envoy reads its configuration at start only. A ConfigMap change rolls the Deployment. |
| Deployments `atenet-router`, `atenet-egress` | `replicas: 1` | `router.replicas`, `egress.replicas` | Default: 1. |
| ConfigMap `k8s-credential-provider-namespace-policy` | applied only when absent, `policies: []`; the operator edits it in the cluster | `policies` from `credentialProvider.namespacePolicies`; the chart owns the ConfigMap | GitOps: the policy lives in values. Default: `[]`, same render. |
| Deployment `k8s-credential-provider`, pod template | no annotations | annotation `checksum/namespace-policy` | The provider reads the policy at start only. A policy change rolls the Deployment. |
| Deployment `atenet-egress`, `egress.upstreamCA` set | upstream TLS trusts the image system roots `/etc/ssl/certs/ca-certificates.crt` | ConfigMap `atenet-egress-upstream-ca`; init container `upstream-ca-bundle` (envoy image) writes system roots plus `egress.upstreamCA` to an emptyDir; clusters `egress_forward_proxy` and `egress_forward_proxy_grpc` trust that file | Origins behind a private CA. Default: empty, same render as the reference install. |

### S3 access

Every pod with an `objectstore-plugin` sidecar reads and writes the snapshot bucket with its own credentials. ate-api-server does not pass credentials to other pods.

| Pod | Sidecar mode | S3 use | ServiceAccount |
|---|---|---|---|
| ate-api-server | `control` | copies snapshots for tags; deletes snapshots nothing refers to | `ate-system/ate-api-server` |
| atelet | `node` | uploads and downloads snapshot files; reads sandbox assets | `ate-system/atelet` |

- Give S3 access to both ServiceAccounts: one EKS Pod Identity association each, or the IRSA annotation `eks.amazonaws.com/role-arn` in `<service>.serviceAccount.annotations`. IAM roles, policies and associations: [EKS](#eks).
- Objects: `<snapshots.s3.prefix>/atespaces/...`; empty prefix: `atespaces/...`.
- `snapshots.s3` is the shared S3 environment of both sidecars, `snapshots.s3.credentialsSecret` included.
- No other pod uses object storage: ate-idp-server, ate-controller, atenet, worker pods.

## Values

One top-level key per service. A value exists only for a setting that changes often or that a known requirement needs. All other fields are fixed in the templates, as the reference install has them.

| Key | Service | Values |
|---|---|---|
| `podcertificateController` | podcertificate-controller | `image`, `replicas` |
| `postgres` | bundled PostgreSQL (one replica) | `image`, `resources`, `storage` |
| `apiServer` | ate-api-server, sidecar `objectstorePlugin` | `image`, `replicas`, `serviceAccountIssuer`, `bootstrapOwners`, `serviceAccount.annotations`, `objectstorePlugin.image` |
| `idpServer` | ate-idp-server | `image`, `replicas` |
| `controller` | ate-controller | `image`, `replicas` |
| `atelet` | atelet, sidecar `objectstorePlugin` | `image`, `serviceAccount.annotations`, `objectstorePlugin.image`, `imageCredentialProvider` |
| `router` | atenet-router, container `envoy` | `image`, `envoy.image`, `replicas`, `ingressAllowedSpiffeIds` |
| `egress` | atenet-egress, containers `sdsmint`, `ext-proc`, `envoy` | `image`, `envoy.image`, `replicas`, `upstreamCA` |
| `credentialProvider` | k8s-credential-provider | `image`, `namespacePolicies` |

Shared keys: `snapshots.s3` (every objectstore-plugin sidecar), `pki` (pool Secrets).

Defaults are the reference install.

## Control plane

- PostgreSQL logins: `substrate_owner_user` and `substrate_readwrite_user`, client certificates from signer `postgres.podcert.ate.dev/identity` (pg_hba.conf `cert`). No role has a password.
- The setup SQL runs at database init only (ADR-0002). If the first init fails, the data directory stays without roles or schema, and ate-api-server cannot log in. Recovery: run the setup again; it is idempotent and keeps data:

  ```bash
  kubectl -n ate-system exec postgres-0 -c postgres -- sh /docker-entrypoint-initdb.d/substrate-setup.sh
  ```
- ate-api-server reaches the database at `postgres.ate-system.svc:5432`, `sslmode=verify-full`.
- `kubectl ate` port-forwards to Service `ate-system/api` and mints a token for ServiceAccount `ate-system/ate-client`, a bootstrap owner by default (`apiServer.bootstrapOwners`). For a shared install, set it to your operator principals.
- A change of `templates/ate-api-server/config.yaml` changes `ate.dev/env-hash` and rolls ate-api-server.

## Dataplane

- atelet runs on every node, also on nodes tainted `ate.dev/sandboxClass=<class>:NoSchedule`. Drain: `--drain-delay=0s`, `--drain-timeout=5m`, `terminationGracePeriodSeconds: 330`.
- Sandbox class: gvisor, SandboxConfig `gvisor-default` (class default). atelet downloads the gVisor release from `gs://gvisor` anonymously: nodes need egress to `storage.googleapis.com`.
- atenet-router admits only clients with a podidentity certificate whose SPIFFE ID is in `router.ingressAllowedSpiffeIds`. Empty (default): no client reaches actors. `kubectl ate proxy actor` presents `spiffe://cluster.local/ns/ate-system/sa/atenet-client`.
- atenet-egress: actor egress through the egress gateway, policed by each actor's EgressPolicy. WebSocket upgrades are rejected. Upstream TLS trusts the image system roots, plus `egress.upstreamCA` when set.
- Egress credential injection: atenet-egress resolves `ate-secret://k8s.io/...` URIs through k8s-credential-provider (mTLS, server name `k8s-credential-provider.ate-system.svc`). An atespace resolves Secrets only in the namespaces `credentialProvider.namespacePolicies` lists for it. k8s-credential-provider reads Secrets in every namespace.

Namespaces are fixed: `ate-system` and `podcertificate-controller-system`. The release namespace is not used.

## Prerequisites

The chart does not check them.

- Kubernetes 1.37: `certificates.k8s.io` serves `podcertificaterequests` and `clustertrustbundles`, in `v1` or `v1beta1`. Check: `kubectl api-resources --api-group=certificates.k8s.io`. Kind: `e2e/kind/cluster.yaml`.
- cert-manager with CRDs (`cert-manager.io/v1`).
- External Secrets Operator with CRDs (`external-secrets.io/v1`).
- A NetworkPolicy implementation. Without one, the `ate-system` NetworkPolicies have no effect.
- An S3 bucket, and S3 access for `ate-system/ate-api-server` and `ate-system/atelet`: [S3 access](#s3-access).
- Egress from the nodes to `storage.googleapis.com:443` (gVisor assets), and from ate-api-server to the `apiServer.serviceAccountIssuer` host.

EKS: [EKS](#eks).

## PKI

The pool Secrets are the seven Secrets the upstream workloads mount, with the upstream names, types and keys:

- cert-manager self-signed CA Certificates `krci-substrate-*` hold the keys.
- ESO ExternalSecrets template each pool Secret, `pool` JSON included.
- CA ID and JWT key ID: `"1"`.

podcertificate-controller starts when `service-dns-ca-pool`, `pod-identity-ca-pool` and `postgres-ca-pool` exist. It then publishes the ClusterTrustBundles `servicedns`, `podidentity` and `postgres` `.podcert.ate.dev:identity:primary-bundle`.

### CA expiry and renewal

- Each CA certificate is valid for `pki.certManager.duration`. cert-manager renews it `pki.certManager.renewBefore` before expiry. Defaults: [Values](#values).
- Renewal keeps the private key (`rotationPolicy: Never`) and the subject. Leaf certificates issued before a renewal verify against the renewed root.
- ESO copies the renewed certificate into the pool Secret within `pki.externalSecrets.refreshInterval`. The upstream workloads reload the pool within a minute after the kubelet updates the mounted Secret.
- Renew now: `cmctl renew --namespace <namespace> krci-substrate-<name>`, then annotate the ExternalSecret with `force-sync=<timestamp>`.
- ESO owns the pool Secrets: edits with `kubectl ate admin` are overwritten at the next refresh.
- Leaf certificates: podcertificate-controller signs them, kubelet renews them in the pod certificate volumes. No action.
- No key rotation: each pool has one key, ID `"1"`. A new key breaks trust: leaf certificates and actor JWTs of the old key fail verification. Do not delete a `krci-substrate-*` Secret: cert-manager then issues a new key.

Renewal runs by itself. Action is necessary only when a Certificate or an ExternalSecret is not ready. Check:

```bash
kubectl get certificates.cert-manager.io -A -o custom-columns='NAMESPACE:.metadata.namespace,NAME:.metadata.name,READY:.status.conditions[?(@.type=="Ready")].status,NOT_AFTER:.status.notAfter,RENEWAL:.status.renewalTime' | grep -E 'NAMESPACE|krci-substrate-'
kubectl get externalsecrets.external-secrets.io -n ate-system
kubectl get externalsecrets.external-secrets.io -n podcertificate-controller-system
```

Expected: six Certificates `READY True`, `RENEWAL` = `NOT_AFTER` minus `pki.certManager.renewBefore`; seven ExternalSecrets `SecretSynced`, `READY True`. A Certificate past `NOT_AFTER`: workloads that verify against it fail TLS; fix cert-manager, then renew now.

## Install

Required values: `snapshots.s3.bucket`, `snapshots.s3.region`, `apiServer.serviceAccountIssuer`.

Argo CD: an Application of this chart, release namespace of your choice (not used). The sync waves order the install: [Install order](#install-order). Argo CD applies `crds/` and updates them on every sync.

Helm:

```bash
helm install krci-substrate ./deploy-templates \
  --set snapshots.s3.bucket=<bucket> --set snapshots.s3.region=<region> \
  --set apiServer.serviceAccountIssuer=<issuer>
```

- Helm installs `crds/` on first install only; it does not upgrade them.
- Helm ignores the sync waves. Pods that start before their dependencies restart until those are ready.

## EKS

AWS resources (S3 bucket, IAM roles, Pod Identity associations), preflight checks with expected output, egress and values: [`docs/eks.md`](https://github.com/KubeRocketCI/krci-substrate/blob/main/docs/eks.md).

## Upgrade

Upstream rules ([upgrade runbook](https://github.com/agent-substrate/substrate/blob/v1.0.1/docs/guides/upgrade.md), [version skew policy](https://github.com/agent-substrate/substrate/blob/v1.0.1/docs/reference/version-skew-policy.md)):

- Patch releases: can be skipped. Minor releases: one at a time. A new major release: reinstall.
- Order, for patch and minor releases: podcertificate-controller; atelet; WorkerPool `spec.workerImage`; ate-api-server and ate-idp-server; CRDs and ate-controller; atenet; SandboxConfig; the rest.

One sync of a new chart version does not keep this order. Wave 3 rolls ate-api-server, ate-idp-server, ate-controller and atenet at the same time ([Install order](#install-order)). The WorkerPools are not chart objects.

Hold groups: image values that keep a service on the old release.

| Group | Image values |
|---|---|
| A | `apiServer.image`, `apiServer.objectstorePlugin.image`, `idpServer.image` |
| B | `controller.image` |
| C | `router.image`, `router.envoy.image`, `egress.image`, `egress.envoy.image`, `credentialProvider.image` |

1. Back up PostgreSQL: `kubectl -n ate-system exec postgres-0 -c postgres -- pg_dump -U postgres atepg > atepg.sql`. The first new ate-api-server pod migrates the schema. A rollback does not undo it.
2. Compare `helm template` of the old and the new chart version for the workloads of each group. A new flag, environment variable or mount: the old image cannot run the new template. Do not hold that group; it moves in step 3, out of the upstream order.
3. Sync the new chart version with groups A, B and C set to the old images. CRDs, SandboxConfig `gvisor-default`, podcertificate-controller and atelet move. Wait: `kubectl -n ate-system rollout status daemonset/atelet`.
4. Set `spec.workerImage` of every WorkerPool to the new release. Wait until every pool is rolled (upstream runbook, step 3).
5. Remove group A. Sync. Wait: `kubectl -n ate-system rollout status deployment/ate-api-server deployment/ate-idp-server`.
6. Remove group B. Sync. Wait: `kubectl -n ate-system rollout status deployment/ate-controller`.
7. Remove group C. Sync. Wait: `kubectl -n ate-system rollout status deployment/atenet-router deployment/atenet-egress deployment/k8s-credential-provider`.
8. Install the `kubectl ate` of the new release.

Differences from the upstream order:

- CRDs and SandboxConfig `gvisor-default` apply in step 3, before atelet and the workers.
- Do not set CRD fields new in the release before step 7 is done.
- A new `defaultVersion` of `gvisor-default` applies from step 3, also to new actors on workers of the old release.

Rollback: the steps in reverse order, with the old chart version and the hold groups set to the new images. The schema migration is not undone. atelet goes back only after every worker is back on the old image.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| epmd-edp | <SupportEPMD-EDP@epam.com> | <https://solutionshub.epam.com/solution/kuberocketci> |

## Source Code

* <https://github.com/KubeRocketCI/krci-substrate>
* <https://github.com/agent-substrate/substrate>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| apiServer.bootstrapOwners | string | `"system:serviceaccount:ate-system:ate-client"` | Comma-separated principals granted owner on global:root. Default: ServiceAccount ate-system/ate-client, the token `kubectl ate` mints. Shared install: the operator principals. |
| apiServer.image.digest | string | `"sha256:5d9f6da2e1446766a48908764891cc3c66cc6ff657279415c0d3839d5e9476ee"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| apiServer.image.repository | string | `"ghcr.io/agent-substrate/substrate/ateapi"` | Image repository. |
| apiServer.image.tag | string | `"v1.0.1"` | Image tag. |
| apiServer.objectstorePlugin.image.digest | string | `"sha256:311cc9cfb9ee8c344f3ebc3e4d5cafb88468840023b62d1c47c6338ed32b0352"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| apiServer.objectstorePlugin.image.repository | string | `"ghcr.io/agent-substrate/substrate/objectstore-plugin"` | Image repository. |
| apiServer.objectstorePlugin.image.tag | string | `"v1.0.1"` | Image tag. |
| apiServer.replicas | int | `2` | Replica count. |
| apiServer.serviceAccount.annotations | object | `{}` | ServiceAccount annotations. IRSA: `eks.amazonaws.com/role-arn: arn:aws:iam::<account>:role/<role>`. |
| apiServer.serviceAccountIssuer | string | `""` |  |
| atelet.image.digest | string | `"sha256:f6707957b470d8a8529e65a4ec3eb1ad5182a607b313b6b1628c7fe6c0e5a9e6"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| atelet.image.repository | string | `"ghcr.io/agent-substrate/substrate/atelet"` | Image repository. |
| atelet.image.tag | string | `"v1.0.1"` | Image tag. |
| atelet.imageCredentialProvider.binDir | string | `"/home/kubernetes/bin"` | Host directory of the credential provider binaries. Upstream default: GKE. EKS: `/etc/eks/image-credential-provider`. |
| atelet.imageCredentialProvider.config | string | `"/etc/srv/kubernetes/cri_auth_config.yaml"` | Host file of the kubelet CredentialProviderConfig. Upstream default: GKE. EKS: `/etc/eks/image-credential-provider/config.json`. |
| atelet.imageCredentialProvider.enabled | bool | `true` | Mount the node credential provider and pass it to atelet. Set false on nodes without one (kind). |
| atelet.objectstorePlugin.image.digest | string | `"sha256:311cc9cfb9ee8c344f3ebc3e4d5cafb88468840023b62d1c47c6338ed32b0352"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| atelet.objectstorePlugin.image.repository | string | `"ghcr.io/agent-substrate/substrate/objectstore-plugin"` | Image repository. |
| atelet.objectstorePlugin.image.tag | string | `"v1.0.1"` | Image tag. |
| atelet.serviceAccount.annotations | object | `{}` | ServiceAccount annotations. IRSA: `eks.amazonaws.com/role-arn: arn:aws:iam::<account>:role/<role>`. |
| controller.image.digest | string | `"sha256:b63519a821f4c702a689caf5b1ff549a8d6134ac3da94def30c71f914a70d614"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| controller.image.repository | string | `"ghcr.io/agent-substrate/substrate/atecontroller"` | Image repository. |
| controller.image.tag | string | `"v1.0.1"` | Image tag. |
| controller.replicas | int | `1` | Replica count. |
| credentialProvider.image.digest | string | `"sha256:46a2872c624c6e3af98984f1097d2205f012ea6c471516ac5189ceb3adef96e5"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| credentialProvider.image.repository | string | `"ghcr.io/agent-substrate/substrate/kubernetes-secrets"` | Image repository. |
| credentialProvider.image.tag | string | `"v1.0.1"` | Image tag. |
| credentialProvider.namespacePolicies | list | `[]` | Namespaces whose Secrets each atespace may resolve: `[{atespace: <name>, allowedNamespaces: [<namespace>]}]`. Default deny: an atespace not listed resolves no Secret. A change restarts the provider. |
| egress.envoy.image.digest | string | `"sha256:6f59332e4e45da4b1600cf1f0c2104c595d875b661be86b4b8c5b16603ad8191"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| egress.envoy.image.repository | string | `"ghcr.io/agent-substrate/substrate/envoy-dataplane"` | Image repository. |
| egress.envoy.image.tag | string | `"v1.0.1"` | Image tag. |
| egress.image.digest | string | `"sha256:ccfa3265be2f45d5ffa7d86ffbe32fa0976426eb1fe1bb28dffbce451c1ea5d7"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| egress.image.repository | string | `"ghcr.io/agent-substrate/substrate/atenet"` | Image repository, shared by the sdsmint and ext-proc containers. |
| egress.image.tag | string | `"v1.0.1"` | Image tag. |
| egress.replicas | int | `1` | Replica count. |
| egress.upstreamCA | string | `""` | PEM CA certificates the egress gateway trusts for upstream TLS, in addition to the image system roots. Certificates only; a private key fails the render. Empty: system roots only. |
| idpServer.image.digest | string | `"sha256:5d9302255998a3f376cbea8d8860488d20b6c030417c0c3ea7fba53a67f2c9f7"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| idpServer.image.repository | string | `"ghcr.io/agent-substrate/substrate/ate-idp-server"` | Image repository. |
| idpServer.image.tag | string | `"v1.0.1"` | Image tag. |
| idpServer.replicas | int | `2` | Replica count. |
| pki.certManager.duration | string | `"8760h"` | Lifetime of each CA certificate (upstream: 365 days). |
| pki.certManager.renewBefore | string | `"720h"` | Renewal lead time before CA certificate expiry. Renewal keeps the private key. |
| pki.externalSecrets.refreshInterval | string | `"1h"` | Interval at which ESO re-reads CA certificate Secrets into pool Secrets. |
| podcertificateController.image.digest | string | `"sha256:46aa01a624053c23080da41ea37937afc5b544cecf77088ab2196b4ffb734b4f"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| podcertificateController.image.repository | string | `"ghcr.io/agent-substrate/substrate/podcertcontroller"` | Image repository. |
| podcertificateController.image.tag | string | `"v1.0.1"` | Image tag. |
| podcertificateController.replicas | int | `1` | Replica count. |
| postgres.image.digest | string | `"sha256:9a8afca54e7861fd90fab5fdf4c42477a6b1cb7d293595148e674e0a3181de15"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| postgres.image.repository | string | `"postgres"` | Image repository, shared by PostgreSQL and the tls-reloader sidecar. |
| postgres.image.tag | string | `"18-alpine"` | Image tag. |
| postgres.resources | object | `{"limits":{"cpu":"16","memory":"2Gi"},"requests":{"cpu":"2","memory":"1Gi"}}` | Upstream base. Sized for the activation load of the whole control plane. |
| postgres.storage.size | string | `"500Gi"` | Upstream base. Headroom for WAL churn; also scales provisioned IOPS on some storage classes. |
| postgres.storage.storageClassName | string | `""` | Empty: cluster default StorageClass. |
| router.envoy.image.digest | string | `"sha256:6f59332e4e45da4b1600cf1f0c2104c595d875b661be86b4b8c5b16603ad8191"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| router.envoy.image.repository | string | `"ghcr.io/agent-substrate/substrate/envoy-dataplane"` | Image repository. |
| router.envoy.image.tag | string | `"v1.0.1"` | Image tag. |
| router.image.digest | string | `"sha256:ccfa3265be2f45d5ffa7d86ffbe32fa0976426eb1fe1bb28dffbce451c1ea5d7"` | Image digest `sha256:<64 hex>`. Empty: tag only. |
| router.image.repository | string | `"ghcr.io/agent-substrate/substrate/atenet"` | Image repository. |
| router.image.tag | string | `"v1.0.1"` | Image tag. |
| router.ingressAllowedSpiffeIds | list | `[]` | SPIFFE IDs of the clients the router lets reach actors. Empty: the router serves no traffic. `kubectl ate proxy actor`: `spiffe://cluster.local/ns/ate-system/sa/atenet-client`. |
| router.replicas | int | `1` | Replica count. |
| snapshots.s3.bucket | string | `""` | Required. S3 bucket name rules. |
| snapshots.s3.credentialsSecret | string | `""` | Existing Secret in ate-system with keys AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY. Credentials come only from a Secret, never from values. Use only for the kind test bed or an S3-compatible store without workload identity. EKS: leave empty (AWS SDK default credential chain) and give S3 access to ate-system/ate-api-server and ate-system/atelet through EKS Pod Identity or IRSA (`<service>.serviceAccount.annotations`). |
| snapshots.s3.endpoint | string | `""` | AWS_ENDPOINT_URL. Empty: the AWS endpoint of the region. |
| snapshots.s3.prefix | string | `""` | Key prefix of the snapshot location `s3://<bucket>/<prefix>/`. Path segments of ASCII letters, digits, `_` and `-`, separated by `/`; not `atespaces`. Objects: `<prefix>/atespaces/...`. Empty: `s3://<bucket>/`, objects `atespaces/...`. |
| snapshots.s3.region | string | `""` | Required. AWS_REGION. |
| snapshots.s3.usePathStyle | bool | `false` | AWS_S3_USE_PATH_STYLE. Set for MinIO, RustFS and other S3-compatible stores. |
