{{/*
Expand the name of the chart.
*/}}
{{- define "edp-tekton.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "edp-tekton.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "edp-tekton.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "edp-tekton.labels" -}}
helm.sh/chart: {{ include "edp-tekton.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/*
Validate values of gitProviders
*/}}
{{- define "edp-tekton.validateGitProviders" -}}
{{- $allowedProviders := list "github" "gitlab" "gerrit" "bitbucket" -}}
{{- range .Values.global.gitProviders }}
  {{- if not (has . $allowedProviders) }}
    {{- printf "Error: Invalid gitProvider %s. The gitProvider must be one of: %s" . (join ", " $allowedProviders) | fail }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define registry for pipelines images
*/}}
{{- define "edp-tekton.registry" -}}
{{- .Values.pipelines.image.registry -}}
{{- end -}}

{{/*
Node.js image (registry + tag) for all npm/pnpm pipelines and tasks
*/}}
{{- define "edp-tekton.nodeImage" -}}
{{- printf "%s/library/node:%s" .Values.pipelines.image.registry .Values.pipelines.image.nodejsTag -}}
{{- end -}}

# Mapping for Java Maven (application and library) pipeliens
{{- define "edp-tekton.resourceMapping.maven" -}}
{{- $registry := .Values.pipelines.image.registry -}}
{{- $mavenVersions := dict -}}
{{- with .Values.pipelines.deployableResources.java -}}
  {{- if .java17 }}
    {{- $mavenVersions = set $mavenVersions "java17" (printf "%s/maven:3.9.0-eclipse-temurin-17" $registry)  }}
  {{- end }}
  {{- if .java21 }}
    {{- $mavenVersions = set $mavenVersions "java21" (printf "%s/maven:3.9.9-eclipse-temurin-21" $registry)  }}
  {{- end }}
  {{- if .java25 }}
    {{- $mavenVersions = set $mavenVersions "java25" (printf "%s/maven:3.9.11-eclipse-temurin-25" $registry)  }}
  {{- end }}
{{- end }}
{{- $mavenVersions | toYaml -}}
{{- end }}

{{- define "edp-tekton.resourceMapping.mavenSonar" -}}
{{- $registry := .Values.pipelines.image.registry -}}
{{- $sonarVersions := dict -}}
{{- with .Values.pipelines.deployableResources.java -}}
  {{- if .java17 }}
    {{- $sonarVersions = set $sonarVersions "java17" (printf "%s/maven:3.9.0-eclipse-temurin-17" $registry) }}
  {{- end }}
  {{- if .java21 }}
    {{- $sonarVersions = set $sonarVersions "java21" (printf "%s/maven:3.9.9-eclipse-temurin-21" $registry) }}
  {{- end }}
  {{- if .java25 }}
    {{- $sonarVersions = set $sonarVersions "java25" (printf "%s/maven:3.9.11-eclipse-temurin-25" $registry) }}
  {{- end }}
{{- end }}
{{- $sonarVersions | toYaml -}}
{{- end }}

# Mapping for Java Gradle (application and library) pipeliens
{{- define "edp-tekton.resourceMapping.gradle" -}}
{{- $registry := .Values.pipelines.image.registry -}}
{{- $gradleVersions := dict -}}
{{- with .Values.pipelines.deployableResources.java -}}
  {{- if .java17 }}
    {{- $gradleVersions = set $gradleVersions "java17" (printf "%s/gradle:7.6.5-jdk17" $registry)  }}
  {{- end }}
  {{- if .java21 }}
    {{- $gradleVersions = set $gradleVersions "java21" (printf "%s/gradle:8.11-jdk21" $registry)  }}
  {{- end }}
  {{- if .java25 }}
    {{- $gradleVersions = set $gradleVersions "java25" (printf "%s/gradle:9.2.1-jdk25" $registry)  }}
  {{- end }}
{{- end }}
{{- $gradleVersions | toYaml -}}
{{- end }}

{{- define "edp-tekton.resourceMapping.gradleSonar" -}}
{{- $registry := .Values.pipelines.image.registry -}}
{{- $sonarVersions := dict -}}
{{- with .Values.pipelines.deployableResources.java -}}
  {{- if .java17 }}
    {{- $sonarVersions = set $sonarVersions "java17" (printf "%s/gradle:7.6.5-jdk17" $registry) }}
  {{- end }}
  {{- if .java21 }}
    {{- $sonarVersions = set $sonarVersions "java21" (printf "%s/gradle:8.11-jdk21" $registry) }}
  {{- end }}
  {{- if .java25 }}
    {{- $sonarVersions = set $sonarVersions "java25" (printf "%s/gradle:9.2.1-jdk25" $registry) }}
  {{- end }}
{{- end }}
{{- $sonarVersions | toYaml -}}
{{- end }}


# Mapping for Go pipelines
{{- define "edp-tekton.resourceMapping.go" -}}
{{- $go := list -}}
{{- with .Values.pipelines.deployableResources.go -}}
  {{- if .beego }}
    {{- $go = append $go "beego" }}
  {{- end }}
  {{- if .gin }}
    {{- $go = append $go "gin" }}
  {{- end }}
  {{- if .operatorsdk }}
    {{- $go = append $go "operator-sdk" }}
  {{- end }}
{{- end }}
{{- $go  -}}
{{- end }}

# Mapping for JS NPM pipelines
{{- define "edp-tekton.resourceMapping.js" -}}
{{- $js := list -}}
{{- with .Values.pipelines.deployableResources.js.npm -}}
  {{- if .vue }}
    {{- $js = append $js "vue" }}
  {{- end }}
  {{- if .angular }}
    {{- $js = append $js "angular" }}
  {{- end }}
  {{- if .express }}
    {{- $js = append $js "express" }}
  {{- end }}
  {{- if .next }}
    {{- $js = append $js "next" }}
  {{- end }}
  {{- if .react }}
    {{- $js = append $js "react" }}
  {{- end }}
{{- end }}
{{- $js  -}}
{{- end }}

# Mapping for JS PNPM pipelines
{{- define "edp-tekton.resourceMapping.js.pnpm" -}}
{{- $js := list -}}
{{- with .Values.pipelines.deployableResources.js.pnpm -}}
  {{- if .vue }}
    {{- $js = append $js "vue" }}
  {{- end }}
  {{- if .angular }}
    {{- $js = append $js "angular" }}
  {{- end }}
  {{- if .express }}
    {{- $js = append $js "express" }}
  {{- end }}
  {{- if .next }}
    {{- $js = append $js "next" }}
  {{- end }}
  {{- if .react }}
    {{- $js = append $js "react" }}
  {{- end }}
{{- end}}
{{- $js  -}}
{{- end }}

# Mapping for Pyhton pipelines
{{- define "edp-tekton.resourceMapping.python" -}}
{{- $python := list -}}
{{- with .Values.pipelines.deployableResources.python -}}
  {{- if .fastapi }}
    {{- $python = append $python "fastapi" }}
  {{- end }}
  {{- if .flask }}
    {{- $python = append $python "flask" }}
  {{- end }}
{{- end }}
{{- $python  -}}
{{- end }}


# Mapping for Csharp pipeliens
{{- define "edp-tekton.resourceMapping.cs" -}}
{{- $registry := .Values.pipelines.image.registry -}}
{{- $csVersions := dict -}}
{{- with .Values.pipelines.deployableResources.cs -}}
  {{- if (index . "dotnet3.1" )}}
    {{- $csVersions = set $csVersions "dotnet-3.1" "mcr.microsoft.com/dotnet/sdk:3.1.423-alpine3.16"  }}
  {{- end }}
  {{- if (index . "dotnet6.0" ) }}
    {{- $csVersions = set $csVersions "dotnet-6.0" "mcr.microsoft.com/dotnet/sdk:6.0.407-alpine3.17"  }}
  {{- end }}
{{- end }}
{{- $csVersions | toYaml -}}
{{- end }}


# Host of the portal, shared by every portal link in the chart. Defaults to the
# krci-portal chart's own default ingress host (krci-portal-<ns>.<dnsWildCard>);
# override .Values.portalHost when the portal ingress uses a custom host.
{{- define "edp-tekton.portalHost" -}}
{{- .Values.portalHost | default (printf "krci-portal-%s.%s" $.Release.Namespace $.Values.global.dnsWildCard) -}}
{{- end -}}

# Base URL of the portal PipelineRun details pages; the single source of truth
# for the portal route, shared by pipelineUrlParam and the reporter.
{{- define "edp-tekton.portalBaseUrl" -}}
https://{{ include "edp-tekton.portalHost" . }}/c/{{ $.Values.clusterName | default ($.Values.global.dnsWildCard | splitList "." | first) }}/cicd/pipelineruns
{{- end -}}

# Define pipelineUrl parameter for Tekton Pipelines
{{- define "edp-tekton.pipelineUrlParam" -}}
- name: pipelineUrl
  default: {{ include "edp-tekton.portalBaseUrl" . }}/$(context.pipelineRun.namespace)/$(context.pipelineRun.name)
  type: string
{{- end -}}

# Interceptor params for the "edp" interceptor reference of gitlab/github/bitbucket
# review Triggers: cancellation of superseded runs and queued commit status reporting.
# The Gerrit review Trigger sets only the cancelInProgress param, because Gerrit
# review reporting is vote-based and queued status reporting does not apply.
{{- define "edp-tekton.reviewInterceptorParams" -}}
{{- if or .Values.pipelines.cancelInProgress .Values.pipelines.queue.enabled }}
      params:
{{- if .Values.pipelines.cancelInProgress }}
        - name: "cancelInProgress"
          value: true
{{- end }}
{{- if .Values.pipelines.queue.enabled }}
        - name: "queuedStatusReporting"
          value: true
{{- end }}
{{- end }}
{{- end -}}

# CEL filter for the GitHub review Trigger. With githubAcl enabled it gates events on
# the GitHub-computed author_association payload field: the PR author for pull_request
# opened/synchronize, the comment author for issue_comment created (so only allowed
# members can /recheck or /ok-to-test an external contributor's PR). Comments on plain
# issues are excluded via has(body.issue.pull_request).
{{- define "edp-tekton.githubReviewCelFilter" -}}
{{- if .Values.githubAcl.enabled -}}
{{- if not .Values.githubAcl.allowedAssociations -}}
{{- fail "githubAcl.allowedAssociations must be a non-empty list when githubAcl.enabled is true (an empty list would block all review pipeline triggers, including /ok-to-test)" -}}
{{- end -}}
{{- $allowed := .Values.githubAcl.allowedAssociations | toJson -}}
(body.action in ['opened', 'synchronize'] && has(body.pull_request) && body.pull_request.author_association in {{ $allowed }}) || (body.action == 'created' && has(body.comment) && has(body.issue.pull_request) && body.comment.author_association in {{ $allowed }})
{{- else -}}
body.action in ['opened', 'synchronize', 'created']
{{- end -}}
{{- end -}}

# PipelineRun spec.status for review runs: born Pending when
# pipelines.queue.pendingPipelineRun is set, so a PipelineRunQueue decides when
# they start.
{{- define "edp-tekton.reviewPipelineRunPending" -}}
{{- if .Values.pipelines.queue.pendingPipelineRun }}
        status: PipelineRunPending
{{- end }}
{{- end -}}

# PipelineRun spec.timeouts for review and build runs.
#
# Guarded on both fields: Tekton only derives a tasks budget (`pipeline - finally`), and
# only cancels tasks still running when it expires, once both are set. Emitting just one
# would read as protection while leaving the reporter skippable, so a half-config is
# dropped rather than half-applied.
{{- define "edp-tekton.pipelineRunTimeouts" -}}
{{- with (.Values.pipelines).timeouts }}
{{- if and .pipeline .finally }}
        timeouts:
          pipeline: {{ .pipeline }}
          finally: {{ .finally }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Secret names held by GitServer.spec.nameSshKeySecret, as a JSON array.

The chart branch must stay identical to the expression in
templates/resources/gitservers/gitserver.yaml, or RBAC silently stops matching
the CR it authorises. The provider branch mirrors the names the portal derives
for GitServers it creates itself.
*/}}
{{- define "edp-tekton.gitServerSecretNames" -}}
{{- $names := list -}}
{{- $providers := .Values.global.gitProviders | default list -}}
{{- range $name, $server := .Values.gitServers -}}
{{- if has $server.gitProvider $providers -}}
{{- $names = append $names (default (printf "ci-%s" $server.gitProvider) $server.nameSshKeySecret) -}}
{{- end -}}
{{- end -}}
{{- range $provider := $providers -}}
{{- $names = append $names (printf "ci-%s" $provider) -}}
{{- if eq $provider "gerrit" -}}
{{- $names = append $names "gerrit-ciuser-sshkey" -}}
{{- end -}}
{{- end -}}
{{- $names | uniq | sortAlpha | toJson -}}
{{- end -}}


{{/*
Whether the Argo CD diff preview is active.

Both flags must be set: the gitops review pipeline references the
argocd-diff-preview Task by name, so rendering the step while the tasks are
not installed would leave an unresolvable taskRef and fail the review
pipeline - the opposite of the step's best-effort contract.
*/}}
{{- define "edp-tekton.argocdDiffPreview.enabled" -}}
{{- if and .Values.pipelines.deployableResources.tasks .Values.pipelines.argocdDiffPreview.enabled -}}
true
{{- end -}}
{{- end -}}
