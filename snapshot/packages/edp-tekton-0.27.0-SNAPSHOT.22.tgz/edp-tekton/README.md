# edp-tekton

![Version: 0.27.0-SNAPSHOT](https://img.shields.io/badge/Version-0.27.0--SNAPSHOT-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.27.0-SNAPSHOT](https://img.shields.io/badge/AppVersion-0.27.0--SNAPSHOT-informational?style=flat-square)
[![Artifact HUB](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/epmdedp)](https://artifacthub.io/packages/search?repo=epmdedp)

A Helm chart for KubeRocketCI Tekton Pipelines

## Additional Information

## Tekton Pipelines

Tekton Pipelines supports four VCS: Gerrit, GitHub, GitLab and BitBucket. To check the VCS Import strategy, please refer to the [KubeRocketCI Documentation](https://docs.kuberocketci.io)).

Tekton Pipelines are implemented and packaged using the [helm-chart](./charts/pipelines-library/) approach. The helm-chart contains:

- `Tasks` - basic building block for Tekton. Some of the tasks are forks from [Upstream Tekton Catalog](https://github.com/tektoncd/catalog).
- `Pipelines`, which consist of `Tasks` and implement logic for the CI flow. KubeRocketCI follows the below approach for pipelines definition:
  - Each type of VCS has its own Pipelines, e.g. for Gerrit, GitHub, GitLab and BitBucket;
  - KubeRocketCI has [two types of Pipelines](https://docs.kuberocketci.io/docs/operator-guide/ci/tekton-overview): `CodeReview` - triggers on Review, `Build` - triggers on Merged Event.
- `Triggers`, `TriggerBindings`, `TriggerTemplates` - defines the logic for specific VCS Events (Gerrit, GitHub, GitLab, BitBucket) and Pipelines.
- `Resources` - Kubernetes resources, that are used from Pipelines, e.g. `ServiceAccount` with [IRSA Enablement](https://docs.kuberocketci.io/docs/developer-guide/aws-reference-architecture#iam-roles-for-service-accounts-irsa), `ConfigMaps` for Maven/Gradle Pipelines, Tekton cache, CodeNarc, CTLint, and PVC to share resources between Tasks.

### EDP Interceptor

EDP Interceptor is used as a component that provides KubeRocketCI metadata for Tekton Pipelines. The code is based on [Upstream implementation](https://github.com/tektoncd/triggers/tree/main/pkg/interceptors).

EDP Interceptor extracts information from VCS payload, like `repository_name`. The `repository_name` has 1-2-1 mapping with `Codebase` (kind: Codebase; apiVersion:v2.edp.epam.com/v1). Interceptor populates Tekton Pipelines with [Codebase SPEC](https://github.com/epam/edp-codebase-operator/blob/master/docs/api.md#codebasespec) data, see the diagram below:

        ┌────────────┐              ┌─────────────────┐       ┌─────────────┐
        │            │              │ EDP Interceptor │       │   Tekton    │
        │  VCS(Git)  ├──────────────►                 ├───────►             │
        │            │              │                 │       │  Pipelines  │
        └──────┬─────┘              └────────┬────────┘       └─────────────┘
               │                             │
        ┌──────┴─────┐                       │ extract
        │    Repo    │                       │
        │            │                       │
        │            │      ┌────────────────▼───────────────┐
        └────────────┘      │ apiVersion: v2.edp.epam.com/v1 │
                            │ kind: Codebase                 │
                            │                                │
                            │ spec:                          │
                            └────────────────────────────────┘

The data, retrieved from the Codebase SPEC, is used in Tekton Pipelines logic.
The docker images for Interceptor are available on the [DockerHub](https://hub.docker.com/repository/docker/epamedp/edp-tekton).
The helm-chart for interceptor deployment is in the same repository by the [charts/interceptor](./charts/interceptor) directory.
Follows [Tekton Interceptor](https://tekton.dev/vault/triggers-main/clusterinterceptors/) paradigm and enriches payload from different Version Control Systems (VCS) like Gerrit, GitHub, GitLab or BitBucket with KubeRocketCI specific data.

**Homepage:** <https://docs.kuberocketci.io>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| epmd-edp | <SupportEPMD-EDP@epam.com> | <https://solutionshub.epam.com/solution/kuberocketci> |
| sergk |  | <https://github.com/SergK> |

## Source Code

* <https://github.com/epam/edp-tekton>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| @epamedp | tekton-cache | 0.4.5 |
| file://../common-library | edp-tekton-common-library | 0.3.22 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| clusterName | string | `""` | Cluster name used to construct the krci-portal pipeline URL (/c/<clusterName>/...). Must match krci-portal configEnv.DEFAULT_CLUSTER_NAME. If left empty, falls back to the first segment of global.dnsWildCard. |
| ctLint.chartSchema | string | `"name: str()\nhome: str()\nversion: str()\ntype: str()\napiVersion: str()\nappVersion: any(str(), num())\ndescription: str()\nkeywords: list(str(), required=False)\nsources: list(str(), required=True)\nmaintainers: list(include('maintainer'), required=True)\ndependencies: list(include('dependency'), required=False)\nicon: str(required=False)\nengine: str(required=False)\ncondition: str(required=False)\ntags: str(required=False)\ndeprecated: bool(required=False)\nkubeVersion: str(required=False)\nannotations: map(str(), str(), required=False)\n---\nmaintainer:\n  name: str(required=True)\n  email: str(required=False)\n  url: str(required=False)\n---\ndependency:\n  name: str()\n  version: str()\n  repository: str()\n  condition: str(required=False)\n  tags: list(str(), required=False)\n  enabled: bool(required=False)\n  import-values: any(list(str()), list(include('import-value')), required=False)\n  alias: str(required=False)\n"` |  |
| ctLint.lintconf | string | `"---\nrules:\n  braces:\n    min-spaces-inside: 0\n    max-spaces-inside: 0\n    min-spaces-inside-empty: -1\n    max-spaces-inside-empty: -1\n  brackets:\n    min-spaces-inside: 0\n    max-spaces-inside: 0\n    min-spaces-inside-empty: -1\n    max-spaces-inside-empty: -1\n  colons:\n    max-spaces-before: 0\n    max-spaces-after: 1\n  commas:\n    max-spaces-before: 0\n    min-spaces-after: 1\n    max-spaces-after: 1\n  comments:\n    require-starting-space: true\n    min-spaces-from-content: 2\n  document-end: disable\n  document-start: disable           # No --- to start a file\n  empty-lines:\n    max: 2\n    max-start: 0\n    max-end: 0\n  hyphens:\n    max-spaces-after: 1\n  indentation:\n    spaces: consistent\n    indent-sequences: whatever      # - list indentation will handle both indentation and without\n    check-multi-line-strings: false\n  key-duplicates: enable\n  line-length: disable              # Lines can be any length\n  new-line-at-end-of-file: enable\n  new-lines:\n    type: unix\n  trailing-spaces: enable\n  truthy:\n    level: warning\n"` |  |
| ctLint.validateMaintainers | bool | `false` |  |
| fullnameOverride | string | `""` |  |
| gitServers | object | `{}` |  |
| githubAcl | object | `{"allowedAssociations":["OWNER","MEMBER","COLLABORATOR"],"enabled":true}` | Restrict who can trigger GitHub review PipelineRuns, based on the author_association field of the webhook payload: the PR author for pull_request opened/synchronize events, the comment author for /recheck and /ok-to-test issue_comment events (Prow-style: an allowed member can approve an external contributor's PR by commenting /ok-to-test). |
| githubAcl.allowedAssociations | list | `["OWNER","MEMBER","COLLABORATOR"]` | GitHub author_association values allowed to trigger review pipelines. Valid values: OWNER, MEMBER, COLLABORATOR, CONTRIBUTOR, FIRST_TIME_CONTRIBUTOR, FIRST_TIMER, NONE. |
| githubOwners | object | `{"checkType":"all","enabled":false}` | DEPRECATED in favor of githubAcl. Enables the upstream Tekton Triggers owners validation (OWNERS file / public org members / collaborators) on pull_request events. WARNING: when enabled, the /recheck comment command stops working for everyone because the upstream interceptor only lets /ok-to-test comments through. More information: https://tekton.dev/docs/triggers/interceptors/#owners-validation-for-pull-requests |
| global.dnsWildCard | string | `""` | a cluster DNS wildcard name |
| global.dockerRegistry.type | string | `"ecr"` | Define Image Registry that will to be used in Pipelines. Can be ecr (default), harbor, dockerhub |
| global.dockerRegistry.url | string | `"<AWS_ACCOUNT_ID>.dkr.ecr.<AWS_REGION>.amazonaws.com/<registry_space>"` | Docker Registry endpoint. In dockerhub case the URL must be specified in accordance with the Kaniko name convention (docker.io/<registry_space>) |
| global.gatewayApi | object | `{"gatewayName":"main-gateway","gatewayNamespace":"envoy-gateway-system"}` | Gateway API parent Gateway that EventListener HTTPRoutes attach to (nginx-ingress -> Envoy Gateway migration). Used only when a gitServer sets eventListener.httproute.enabled=true; ignored otherwise. |
| global.gatewayApi.gatewayName | string | `"main-gateway"` | Name of the parent Gateway resource |
| global.gatewayApi.gatewayNamespace | string | `"envoy-gateway-system"` | Namespace of the parent Gateway resource |
| global.gerritHost | string | `"gerrit"` | Gerrit Host URL, must be specified if gerrit is enabled |
| global.gitProviders | list | `["bitbucket","gerrit","github","gitlab"]` | Deploy Kubernetes Resources for the specific Git Provider. Can be gerrit, gitlab, github (default) |
| global.platform | string | `"kubernetes"` | platform type that can be "kubernetes" or "openshift" |
| grafana.dashboards.labelKey | string | `"grafana_dashboard"` |  |
| grafana.dashboards.labelValue | string | `"1"` |  |
| grafana.enabled | bool | `false` |  |
| grafana.serviceMonitor.prometheusReleaseLabels.release | string | `"prom"` |  |
| interceptor.affinity | object | `{}` | Affinity settings for pod assignment |
| interceptor.enabled | bool | `true` | Deploy KubeRocketCI interceptor as a part of pipeline library when true. Default: true |
| interceptor.extraSecretNames | list | `[]` | Additional git server secret names the interceptor is allowed to read |
| interceptor.extraVolumeMounts | list | `[]` | Additional volume mounts, e.g. mount a private CA into /etc/ssl/certs to trust it |
| interceptor.extraVolumes | list | `[]` | Additional volumes, e.g. a ConfigMap with a private CA certificate for git servers with self-signed TLS (required for pipelines.queue.enabled against such servers) |
| interceptor.image.pullPolicy | string | `"IfNotPresent"` |  |
| interceptor.image.repository | string | `"epamedp/edp-tekton"` |  |
| interceptor.image.tag | string | `nil` | Overrides the image tag whose default is the chart appVersion. |
| interceptor.imagePullSecrets | list | `[]` |  |
| interceptor.logLevel | string | `"info"` | Interceptor log level (debug, info, warn, error). debug additionally logs the full webhook request/response payloads. |
| interceptor.nameOverride | string | `"tekton-interceptor"` |  |
| interceptor.nodeSelector | object | `{}` | Node labels for pod assignment |
| interceptor.podAnnotations | object | `{}` |  |
| interceptor.podSecurityContext | object | `{}` |  |
| interceptor.resources | object | `{"limits":{"cpu":"70m","memory":"60Mi"},"requests":{"cpu":"50m","memory":"40Mi"}}` | The resource limits and requests for the Tekton Interceptor |
| interceptor.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| interceptor.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| interceptor.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| interceptor.securityContext.runAsGroup | int | `65532` |  |
| interceptor.securityContext.runAsNonRoot | bool | `true` |  |
| interceptor.securityContext.runAsUser | int | `65532` |  |
| interceptor.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| interceptor.serviceAccount.name | string | `""` | If not set, a name is generated using the fullname template |
| interceptor.tolerations | list | `[]` | Toleration labels for pod assignment |
| kaniko.customCert | bool | `false` | Save cert in secret "custom-ca-certificates" with key ca.crt |
| kaniko.image.repository | string | `"gcr.io/kaniko-project/executor"` |  |
| kaniko.image.tag | string | `"v1.12.1"` |  |
| kaniko.roleArn | string | `""` | AWS IAM role to be used for kaniko pod service account (IRSA). Format: arn:aws:iam::<AWS_ACCOUNT_ID>:role/<AWS_IAM_ROLE_NAME> |
| nameOverride | string | `""` |  |
| pipelines.argocdDiffPreview | object | `{"commentImage":"python:3.12-alpine","enabled":false,"innerArgocdNamespace":"argocd","kubeconfigSecret":"vc-argocd-diff-preview","namespace":"argocd-diff-preview","renderTimeoutSeconds":"300","toolImage":"dagandersen/argocd-diff-preview:v0.2.11","utilImage":"alpine/k8s:1.33.4"}` | Argo CD Diff Preview settings for the GitOps review pipelines. When enabled, the gitops review pipeline renders an MR manifest diff via the standing argocd-diff-preview vcluster (installed by the argocd-diff-preview cluster addon) and posts it as an MR comment; it stays best-effort at runtime and skips silently if the addon is unhealthy. |
| pipelines.argocdDiffPreview.commentImage | string | `"python:3.12-alpine"` | Python image for posting the MR comment. |
| pipelines.argocdDiffPreview.enabled | bool | `false` | Install the diff-preview task and wire it into the gitops review pipeline. Enable this together with the argocd-diff-preview cluster addon; leave disabled otherwise. |
| pipelines.argocdDiffPreview.innerArgocdNamespace | string | `"argocd"` | Namespace of the Argo CD instance inside the argocd-diff-preview vcluster (must match the addon's embedded Argo CD bootstrap configuration). |
| pipelines.argocdDiffPreview.kubeconfigSecret | string | `"vc-argocd-diff-preview"` | Kubeconfig secret exported by the vcluster addon. |
| pipelines.argocdDiffPreview.namespace | string | `"argocd-diff-preview"` | Namespace of the argocd-diff-preview vcluster addon. |
| pipelines.argocdDiffPreview.renderTimeoutSeconds | string | `"300"` | Maximum time in seconds to wait for Argo CD to render all applications. |
| pipelines.argocdDiffPreview.toolImage | string | `"dagandersen/argocd-diff-preview:v0.2.11"` | argocd-diff-preview tool image. |
| pipelines.argocdDiffPreview.utilImage | string | `"alpine/k8s:1.33.4"` | Utility image with git/kubectl/jq/yq for the connect and prepare-and-export steps. |
| pipelines.cancelInProgress | bool | `false` | Cancel in-progress review PipelineRuns when a new commit is pushed to the same Pull Request / Merge Request / Gerrit change. Handled entirely by the KRCI interceptor - no extra components are required. Cancellation is graceful (spec.status: CancelledRunFinally), so finally tasks of the superseded run still execute. |
| pipelines.deployableResources | object | `{"autotests":true,"c":{"cmake":true,"make":true},"cs":{"dotnet3.1":false,"dotnet6.0":false},"deploy":true,"docker":true,"gitops":true,"go":{"beego":true,"gin":true,"operatorsdk":true},"groovy":true,"helm":true,"helm-pipeline":true,"infrastructure":true,"java":{"java17":true,"java21":true,"java25":true,"java25SkipSonar":true},"js":{"npm":{"angular":true,"antora":true,"express":true,"next":true,"react":true,"vue":true},"pnpm":{"angular":true,"antora":true,"express":true,"next":true,"react":true,"vue":true}},"opa":false,"python":{"ansible":true,"fastapi":true,"flask":true,"python3.13":false},"security":true,"tasks":true,"terraform":true}` | This section contains the list of pipelines and tasks that will be installed. |
| pipelines.deployableResources.c | object | `{"cmake":true,"make":true}` | This section control the installation of the review and build pipelines. |
| pipelines.deployableResources.deploy | bool | `true` | This flag control the installation of the Deploy pipelines. |
| pipelines.deployableResources.java.java25SkipSonar | bool | `true` | This parameter disables the Sonar check for Java 25, as it is not currently supported. Ref: https://docs.sonarsource.com/sonarqube-community-build/analyzing-source-code/languages/java#suoported-versions |
| pipelines.deployableResources.tasks | bool | `true` | This flag control the installation of the tasks. |
| pipelines.image.nodejsTag | string | `"24.18.0-alpine3.24"` | Node.js image tag used across all npm/pnpm pipelines and tasks |
| pipelines.image.registry | string | `"docker.io"` | Registry for tekton pipelines images. Default: docker.io |
| pipelines.imagePullSecrets | list | `[]` | List of image pull secrets used by the Tekton ServiceAccount for pulling images from private registries. Example: imagePullSecrets:   - name: regcred |
| pipelines.podTemplate | list | `[]` | This section allows to determine on which nodes to run tekton pipelines |
| pipelines.queue.enabled | bool | `false` | Post a pending/QUEUED commit status from the interceptor at webhook time, so a review PipelineRun waiting in the queue shows a check in the VCS UI before it starts. Covers gitlab, github and bitbucket. |
| pipelines.queue.pendingPipelineRun | bool | `false` | Create review PipelineRuns in the Pending state (spec.status: PipelineRunPending), so a PipelineRunQueue decides when they start. Requires the tekton-pipeline-queue operator; without it Pending PipelineRuns never start. |
| pipelines.timeouts.finally | string | `"10m0s"` | Duration reserved for finally tasks; the remainder is the tasks budget. Only needs to fit the status reporter, so it can stay small. Must be less than `pipeline`. |
| pipelines.timeouts.pipeline | string | `"1h10m0s"` | Maximum duration of the whole PipelineRun, tasks and finally combined. The default is the 60m tasks get from Tekton's default-timeout-minutes plus the `finally` reservation, so the reporter's headroom does not shorten existing builds. |
| portalHost | string | `""` | Portal host used to build pipeline links in commit statuses and reporter PR comments. Set this when the krci-portal ingress uses a custom host. If left empty, defaults to the krci-portal chart's default host krci-portal-<namespace>.<global.dnsWildCard>. |
| reporter.affinity | object | `{}` | Affinity settings for pod assignment |
| reporter.commentStrategy | string | `"update"` | Report comment strategy: 'update' edits the previous report comment of the same pull request, 'new' always creates a new comment |
| reporter.enabled | bool | `true` | Deploy the Tekton Reporter as a part of the pipeline library when true. Default: true |
| reporter.extraVolumeMounts | list | `[]` | Additional volume mounts, e.g. mount a private CA into /etc/ssl/certs to trust it |
| reporter.extraVolumes | list | `[]` | Additional volumes, e.g. a ConfigMap with a private CA certificate for git servers with self-signed TLS |
| reporter.image.pullPolicy | string | `"IfNotPresent"` |  |
| reporter.image.repository | string | `"epamedp/edp-tekton"` |  |
| reporter.image.tag | string | `nil` | Overrides the image tag whose default is the chart appVersion. |
| reporter.imagePullSecrets | list | `[]` |  |
| reporter.logsReporting | bool | `false` | Publish trailing log lines of failed steps in pull request report comments. Disabled by default so pipeline output, which may carry secrets, is not republished to the VCS; the reporter then also stops reading pod logs and is not granted pods/log access. When enabled, a single PipelineRun or a whole GitServer can still opt out (or back in) via the `app.edp.epam.com/reporter-logs: "true"/"false"` annotation; the PipelineRun annotation wins over the GitServer one. Default: false |
| reporter.nameOverride | string | `"tekton-reporter"` |  |
| reporter.nodeSelector | object | `{}` | Node labels for pod assignment |
| reporter.podAnnotations | object | `{}` |  |
| reporter.podSecurityContext | object | `{}` |  |
| reporter.resources | object | `{"limits":{"cpu":"100m","memory":"128Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}` | The resource limits and requests for the Tekton Reporter |
| reporter.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| reporter.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| reporter.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| reporter.securityContext.runAsGroup | int | `65532` |  |
| reporter.securityContext.runAsNonRoot | bool | `true` |  |
| reporter.securityContext.runAsUser | int | `65532` |  |
| reporter.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| reporter.serviceAccount.name | string | `""` | If not set, a name is generated using the fullname template |
| reporter.tailLines | int | `100` | Number of trailing log lines published for every failed step (used only when logsReporting is true) |
| reporter.tolerations | list | `[]` | Toleration labels for pod assignment |
| tekton-cache.enabled | bool | `true` | Enables the Tekton-cache subchart. |
| tekton-cache.url | string | `"http://tekton-cache:8080"` | Defines the URL to the tekton-cache. Default: http://tekton-cache:8080 |
| tekton.configs.gradleConfigMap | string | `"custom-gradle-settings"` | Default configuration maps for provisioning init.gradle file, REPOSITORY_SNAPSHOTS_PATH and REPOSITORY_RELEASES_PATH environment variables. |
| tekton.configs.mavenConfigMap | string | `"custom-maven-settings"` | Default configuration map for provisioning Maven settings.xml file. To use custom Maven settings.xml configuration file, the user should prepare another configuration map and update "mavenConfigMap". For reference see https://github.com/epam/edp-tekton/blob/master/charts/pipelines-library/templates/resources/cm-maven-settings.yaml |
| tekton.configs.npmConfigMap | string | `"custom-npm-settings"` | Default configuration maps for provisioning NPM .npmrc files. To use custom NPM .npmrc configuration file, the user should prepare another configuration map and update "npmConfigMap". For reference see https://github.com/epam/edp-tekton/blob/master/charts/pipelines-library/templates/resources/cm-npm-settings.yaml |
| tekton.configs.nugetConfigMap | string | `"custom-nuget-settings"` | Default configuration maps for provisioning nuget.config file. |
| tekton.configs.pythonConfigMap | string | `"custom-python-settings"` | Default configuration maps for provisioning PIP_TRUSTED_HOST, PIP_INDEX_PATH, PIP_INDEX_URL_PATH, REPOSITORY_SNAPSHOTS_PATH and REPOSITORY_RELEASES_PATH environment variables for Python tasks. |
| tekton.containerBuildTool | string | `"kaniko"` | Defines which image build and verification tools Tekton pipelines use. buildTool options: kaniko | buildkit |
| tekton.packageRegistriesSecret.enabled | bool | `false` | Set this as `true` if the secret should be available in Pipelines |
| tekton.packageRegistriesSecret.name | string | `"package-registries-auth-secret"` | Secret name that will be used in Pipelines. Default: package-registries-auth-secret |
| tekton.resources | object | `{"limits":{"cpu":"2","memory":"3Gi"},"requests":{"cpu":"500m","memory":"1Gi"}}` | The resource limits and requests for the Tekton Tasks |
| tekton.workspaceSize | string | `"7Gi"` | Tekton workspace size. Most cases 1Gi is enough. It's common for all pipelines |
