{{/*
Expand the name of the chart.
*/}}
{{- define "krci-security-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "krci-security-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "krci-security-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "krci-security-operator.labels" -}}
helm.sh/chart: {{ include "krci-security-operator.chart" . }}
{{ include "krci-security-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "krci-security-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "krci-security-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Fully qualified image reference.
*/}}
{{- define "krci-security-operator.image" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion | toString }}
{{- if .Values.image.registry }}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository $tag }}
{{- else }}
{{- printf "%s:%s" .Values.image.repository $tag }}
{{- end }}
{{- end }}

{{/*
Cluster name: required, a lowercase RFC 1123 DNS label of at most 63 characters (the rule of the operator).
*/}}
{{- define "krci-security-operator.clusterName" -}}
{{- $name := required "clusterName is required: the unique name of this cluster in DefectDojo" .Values.clusterName }}
{{- if and $name (or (gt (len $name) 63) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" $name))) }}
{{- fail (printf "clusterName must be a lowercase RFC 1123 DNS label of at most 63 characters, got %q" $name) }}
{{- end }}
{{- $name }}
{{- end }}
