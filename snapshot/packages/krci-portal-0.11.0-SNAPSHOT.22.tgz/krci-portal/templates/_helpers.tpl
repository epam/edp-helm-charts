{{/*
Expand the name of the chart.
*/}}
{{- define "krci-portal.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "krci-portal.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "krci-portal.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "krci-portal.labels" -}}
helm.sh/chart: {{ include "krci-portal.chart" . }}
{{ include "krci-portal.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "krci-portal.selectorLabels" -}}
app.kubernetes.io/name: {{ include "krci-portal.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "krci-portal.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "krci-portal.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the secretstore to use
*/}}
{{- define "krci-portal.secretStoreName" -}}
  {{- if .Values.externalSecrets.enabled }}
    {{- if eq .Values.externalSecrets.type "aws" }}
      {{- printf "%s-%s" "aws" .Values.externalSecrets.secretProvider.aws.service | lower }}
    {{- end }}
    {{- if eq .Values.externalSecrets.type "generic" }}
      {{- $secretStoreName := required "Secret store name is not defined" .Values.externalSecrets.secretProvider.generic.secretStore.name | lower }}
      {{- printf "%s" $secretStoreName }}
    {{- end }}
  {{- end }}
{{- end }}

{{/* Server DB directory. Hardcoded contract, not user-configurable. */}}
{{- define "krci-portal.dbMountPath" -}}
/app/db
{{- end -}}

{{/*
Host of the 'edpDefault' sentinel: <fullname>-<namespace>.<wildcard>. The Ingress and the HTTPRoute both
render it. The wildcard is the first non-empty of .wildcard (the caller's own value, named in the error by
.wildcardKey), ingress.dnsWildcard and global.dnsWildCard. The global map is absent when a release reuses
values stored by a chart version that did not declare it.
*/}}
{{- define "krci-portal.defaultHost" -}}
{{- $global := .root.Values.global | default dict -}}
{{- $keys := list .wildcardKey "ingress.dnsWildcard" "global.dnsWildCard" | compact -}}
{{- $message := printf "the 'edpDefault' host needs a DNS wildcard: set %s or %s" (join ", " (initial $keys)) (last $keys) -}}
{{- $wildcard := required $message (coalesce .wildcard .root.Values.ingress.dnsWildcard $global.dnsWildCard) -}}
{{- printf "%s-%s.%s" (include "krci-portal.fullname" .root) .root.Release.Namespace $wildcard -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for External Secrets
*/}}
{{- define "app.externalSecrets.apiVersion" -}}
  {{- if .Capabilities.APIVersions.Has "external-secrets.io/v1" -}}
    {{- print "external-secrets.io/v1" -}}
  {{- else if .Capabilities.APIVersions.Has "external-secrets.io/v1beta1" -}}
    {{- print "external-secrets.io/v1beta1" -}}
  {{- else -}}
    {{- print "external-secrets.io/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Tekton Results CA certificate (PEM), trimmed. Empty when not set.
*/}}
{{- define "krci-portal.tektonResultsCaCert" -}}
{{- (.Values.tektonResults | default dict).caCert | default "" | trim -}}
{{- end }}

{{/*
Directory of the mounted Tekton Results CA certificate.
*/}}
{{- define "krci-portal.tektonResultsCaDir" -}}
/etc/tekton-results-ca
{{- end }}

{{/*
configEnv.AGENT_SUBSTRATE_URL, trimmed. Empty when not set.
*/}}
{{- define "krci-portal.agentSubstrateUrl" -}}
{{- (.Values.configEnv | default dict).AGENT_SUBSTRATE_URL | default "" | toString | trim -}}
{{- end }}

{{/*
Host of configEnv.AGENT_SUBSTRATE_URL, without the port: the audience of the Agent Substrate token.
Fails when the URL is not https:// or the release uses the default ServiceAccount.
*/}}
{{- define "krci-portal.agentSubstrateHost" -}}
{{- $url := urlParse (include "krci-portal.agentSubstrateUrl" .) -}}
{{- $host := (split ":" $url.host)._0 -}}
{{- if or (ne $url.scheme "https") (not $host) -}}
{{- fail "configEnv.AGENT_SUBSTRATE_URL must be an https://<host>[:<port>] URL" -}}
{{- end -}}
{{- if eq (include "krci-portal.serviceAccountName" .) "default" -}}
{{- fail "configEnv.AGENT_SUBSTRATE_URL does not work with the default ServiceAccount: set serviceAccount.create or serviceAccount.name" -}}
{{- end -}}
{{- $host -}}
{{- end }}

{{/*
Mount path of the Agent Substrate token and CA. The portal server reads this fixed path.
*/}}
{{- define "krci-portal.agentSubstrateMountPath" -}}
/var/run/agent-substrate
{{- end }}
